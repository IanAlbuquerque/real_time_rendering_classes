#include "uvwrapper.h"

UVWrapper::UVWrapper()
{

}
