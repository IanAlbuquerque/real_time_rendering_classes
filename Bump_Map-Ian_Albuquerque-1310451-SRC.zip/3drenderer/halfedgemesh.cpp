#include "halfedgemesh.h"

HalfEdgeMesh::HalfEdgeMesh()
{

}
