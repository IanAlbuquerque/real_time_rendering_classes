#ifndef HALFEDGEMESH_H
#define HALFEDGEMESH_H

class HalfEdgeMesh
{
public:
  HalfEdgeMesh();
};

class HalfEdgeMesh
{
public:
  HalfEdgeMesh();
};

class HalfEdgeMesh
{
public:
  HalfEdgeMesh();
};

class HalfEdgeMesh
{
public:
  HalfEdgeMesh();
};

#endif // HALFEDGEMESH_H
